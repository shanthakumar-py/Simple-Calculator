let defalutresult = 0;
let currentResult = defalutresult;

function outputCalculation(operator, resultBefore, resultAfter) {
  const calculateDesc = `${resultBefore} ${operator} ${resultAfter} `;
  outputResult(currentResult, calculateDesc);
}
function add() {
  const initialResult = currentResult;
  currentResult = parseInt(currentResult) + parseInt(userInput.value);
  const defaultValue = parseInt(userInput.value);
  outputCalculation("+", initialResult, defaultValue);
}

function sub() {
  const initialResult = currentResult;
  currentResult = parseInt(currentResult) - parseInt(userInput.value);
  const defaultValue = parseInt(userInput.value);
  outputCalculation("-", initialResult, defaultValue);
}

function multi() {
  const initialResult = currentResult;
  currentResult = parseInt(currentResult) * parseInt(userInput.value);
  const defaultValue = parseInt(userInput.value);
  outputCalculation("*", initialResult, defaultValue);
}

function div() {
  const initialResult = currentResult;
  currentResult = parseInt(currentResult) / parseInt(userInput.value);
  const defaultValue = parseInt(userInput.value);
  outputCalculation("/", initialResult, defaultValue);
}

addBtn.addEventListener("click", add);
subtractBtn.addEventListener("click", sub);
multiplyBtn.addEventListener("click", multi);
divideBtn.addEventListener("click", div);
